
package com.mycompany.cis331project3;

import java.util.*;

public class SalesLead {
    // Data Types
    private int id;
    private String sellerName;
    private String leadAddress;
    private String email;
    private String phone;
    private String note;
    // Constructors
    public SalesLead(int id, String sellerName, String leadAddress, String email, String phone, String note) {
        this.id = id;
        this.sellerName = sellerName;
        this.leadAddress = leadAddress;
        this.email = email;
        this.phone = phone;
        this.note = note;
    }
    // Constructors
    public SalesLead (int id, String sellerName, String leadAddress) {
        this.id = id;
        this.sellerName = sellerName;
        this.leadAddress = leadAddress;
    }
    // Member Methods
    // Getters 
    public int getId() { return id; }
    public String getSellerName() { return sellerName; }
    public String getLeadAddress() { return leadAddress; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getNote() { return note; }
    // Setters
    public void setNote(String note) { this.note = note; }
    // Provides a string representation of the sales leads information
    @Override
    public String toString() {
        return "Lead Seller: " + sellerName + "Lead Address: " + leadAddress + "Email: " + email + ", Phone: " + phone + 
                (note != null ? ", Note: " + note : "");
    }
}
    

