

package com.mycompany.cis331project3;

import java.io.*; 
import java.util.*;
/*

Title: Group Project Part 3 - Fine Tuning the Data Model

Authors: Simon Fossett, Rob Parker, and Jeffrey Sterns

Team: BeanLine Logic

Date: 12/13/25

Class: CIS 331 Section 0002 Ezell

*/

public class CIS331Project3 {
    
    public static Scanner keyboardIn = new Scanner(System.in);
    public static final int MAX_ENTRIES = 100;
    
    private static ArrayList<Agent> agents = new ArrayList<>();
    private static ArrayList<BuyerSeller> buyerSellers = new ArrayList<>();
    private static ArrayList<Property> properties = new ArrayList<>();

    public static void main(String[] args) {
        boolean running = true;
        while (running) {
            System.out.println("Real Estate Management System\n-----------------------------");
            System.out.println("1.  Amortization of Home Loan");
            System.out.println("2.  LOAD Amortization");
            System.out.println("3.  Add Agent");
            System.out.println("4.  Edit Agents");
            System.out.println("5.  Add Buyer/Seller");
            System.out.println("6.  Edit Buyers/Sellers");
            System.out.println("7.  Add Property");
            System.out.println("8.  Edit Property's");
            System.out.println("9.  Add Sales Lead");
            System.out.println("10. Assign Agents to Property");
            System.out.println("11. Assign Buyers/Sellers to Property");
            System.out.println("12. View Histogram");
            System.out.println("13. Select Agent");
            System.out.println("14. Select Property");
            System.out.println("15. SAVE DATA");
            System.out.println("16. LOAD DATA");
            System.out.println("17. EXIT");
            
            System.out.print("Enter choice: ");
            int choice = keyboardIn.nextInt();
            keyboardIn.nextLine(); 
            
            switch (choice) {
                case 1 -> amortizationHomeLoan();
                case 2 -> loadAmortization();
                case 3 -> addAgent();
                case 4 -> editAgent();
                case 5 -> addBuyerSeller();
                case 6 -> editBuyerSeller();
                case 7 -> addProperty();
                case 8 -> editProperty();
                case 9 -> addSalesLead();
                case 10 -> assignAgentToProperty();
                case 11 -> assignBuyerSellerToProperty();
                case 12 -> viewHistogram();
                case 13 -> selectAgent();
                case 14 -> selectProperty();
                case 15 -> saveData();
                case 16 -> loadData();
                case 17 -> running = false;
                default -> System.out.println("Invalid choice. Try again.");
            }
        }
        keyboardIn.close();
    }
    // Method to add sales lead to the system
    public static void addSalesLead() {
        System.out.println("\n--- Add New Sales Lead ---");

        // Generate ID for new sales lead 
        int id = 3001 + getTotalSalesLeadsCount(); 
    
        System.out.print("Enter seller name: ");
        String sellerName = keyboardIn.nextLine();
        System.out.print("Enter lead address: ");
        String leadAddress = keyboardIn.nextLine();
        System.out.print("Enter email: ");
        String email = keyboardIn.nextLine();
        System.out.print("Enter phone number: ");
        String phone = keyboardIn.nextLine();
        System.out.print("Enter notes about the interaction: ");
        String note = keyboardIn.nextLine();

        System.out.println("\n--- Available Agents ---");
        displayAllAgents();

        System.out.print("\nEnter Agent ID to assign this lead: ");
        int agentId = keyboardIn.nextInt();
        keyboardIn.nextLine();

        Agent agent = findAgentById(agentId);
        if (agent != null) {
           
            SalesLead newLead = new SalesLead(id, sellerName, leadAddress, email, phone, note);
            agent.addSalesLead(newLead);
            System.out.println("Sales lead added with ID: " + id + " and assigned to Agent ID: " + agentId);
        } else {
            System.out.println("Invalid Agent ID. Lead not assigned.");
        }
    }

    private static int getTotalSalesLeadsCount() {
        int count = 0;
        for (Agent agent : agents) {
            count += agent.getSalesLeads().size();
        }
        return count;
    }
    // Method used to add agent to the system
    public static void addAgent() {
        System.out.print("Enter agent name: ");
        String name = keyboardIn.nextLine();
        System.out.println("Enter agent's email: "); 
        String email = keyboardIn.nextLine();
        System.out.println("Enter agent's phone number: ");
        String phone = keyboardIn.nextLine();
        
        int id = agents.size() + 1;
        agents.add(new Agent(id, name, email, phone));
        System.out.println("Agent added successfully with ID: " + id);
    }
    // Method used to edit agent
    public static void editAgent() {
        System.out.println("-----------------\nCURRENT AGENTS:\n-----------------");
        displayAllAgents();
        
        System.out.print("\nEnter Agent ID to edit: "); 
        int id = keyboardIn.nextInt();
        keyboardIn.nextLine();
    
        Agent agent = findAgentById(id);
        if (agent != null) {
            System.out.println("Enter new agent name: ");
            agent.setName(keyboardIn.nextLine());
            System.out.println("Enter new agent email: ");
            agent.setEmail(keyboardIn.nextLine());
            System.out.println("Enter new agent phone number: ");
            agent.setPhone(keyboardIn.nextLine());
            System.out.println("Agent updated successfully.");
        } else {
            System.out.println("Invalid Agent ID.");
        }
    }
    // Method used to find agent by unique ID
    private static Agent findAgentById(int id) {
        for (Agent agent : agents) {
            if (agent.getId() == id) {
                return agent;
            }
        }
        return null;
    }
    // Method used to display current agents
    private static void displayAllAgents() {
        if (agents.isEmpty()) {
            System.out.println("No agents found.");
            return;
        }
        for (Agent agent : agents) {
            System.out.printf("ID: %d, Name: %s, Email: %s, Phone: %s%n",
                    agent.getId(), agent.getName(), agent.getEmail(), agent.getPhone());
        }
    }

    // Method used to add buyer/seller to system
    public static void addBuyerSeller() {
        System.out.print("Enter buyer/seller name: ");
        String name = keyboardIn.nextLine();
        System.out.println("Enter buyer/seller email: ");
        String email = keyboardIn.nextLine();
        System.out.println("Enter buyer/seller phone number: "); 
        String phone = keyboardIn.nextLine();
        
        int id = buyerSellers.size() + 1001;
        buyerSellers.add(new BuyerSeller(id, name, email, phone));
        System.out.println("Buyer/Seller added successfully with ID: " + id);
    }
    // Method used to edit buyer/seller
    public static void editBuyerSeller() {
        System.out.println("---------------------------\nCURRENT BUYERS AND SELLERS:\n---------------------------");
        displayAllBuyerSellers();
        
        System.out.print("\nEnter Buyer/Seller ID to edit: ");
        int id = keyboardIn.nextInt();
        keyboardIn.nextLine();
    
        BuyerSeller buyerSeller = findBuyerSellerById(id);
        if (buyerSeller != null) {
            System.out.println("Enter new buyer/seller name: ");
            buyerSeller.setName(keyboardIn.nextLine());
            System.out.println("Enter new buyer/seller email: ");
            buyerSeller.setEmail(keyboardIn.nextLine());
            System.out.println("Enter new buyer/seller phone number: ");
            buyerSeller.setPhone(keyboardIn.nextLine());
            System.out.println("Buyer/Seller updated successfully.");
        } else {
            System.out.println("Invalid Buyer/Seller ID.");
        }
    }
    // Method used to find buyer/seller by their unique ID
    private static BuyerSeller findBuyerSellerById(int id) {
        for (BuyerSeller buyerSeller : buyerSellers) {
            if (buyerSeller.getId() == id) {
                return buyerSeller;
            }
        }
        return null;
    }
    // Method used to display all current buyers/sellers
    private static void displayAllBuyerSellers() {
        if (buyerSellers.isEmpty()) {
            System.out.println("No buyers or sellers found.");
            return;
        }
        for (BuyerSeller buyerSeller : buyerSellers) {
            System.out.printf("ID: %d, Name: %s, Email: %s, Phone: %s%n",
                    buyerSeller.getId(), buyerSeller.getName(), buyerSeller.getEmail(), buyerSeller.getPhone());
        }
    }

    // Method used to add properties to system
    public static void addProperty() {
        System.out.print("Enter property price: ");
        double price = keyboardIn.nextDouble();
        keyboardIn.nextLine();
        System.out.println("Enter property address: ");
        String address = keyboardIn.nextLine();
    
        int id = properties.size() + 2001;
        Property property = new Property(id, address, price); 
    
        boolean addMoreSales = true;
        while (addMoreSales) {
            System.out.print("Enter year of sale: ");
            int year = keyboardIn.nextInt();
            System.out.print("Enter sale price: ");
            double salePrice = keyboardIn.nextDouble();
            keyboardIn.nextLine();
        
            property.addSaleEvent(new SaleEvent(year, salePrice));  
        
            System.out.print("Add another sale? (yes/no): ");
            String response = keyboardIn.nextLine().toLowerCase();
            addMoreSales = response.equals("yes");
        }
    
        properties.add(property);
        System.out.println("Property added successfully with ID: " + id);
    }
    // Method used to edit a property
    public static void editProperty() {
        System.out.println("-----------------\nCURRENT PROPERTIES:\n-----------------");
        displayAllProperties();
    
        System.out.print("\nEnter Property ID to edit: ");
        int id = keyboardIn.nextInt();
        keyboardIn.nextLine();

        Property property = findPropertyById(id);
        if (property != null) {
            System.out.print("Enter new property price: ");
            property.setPrice(keyboardIn.nextDouble());
            keyboardIn.nextLine();
            System.out.println("Enter new property address: "); 
            property.setAddress(keyboardIn.nextLine());
    
            
            System.out.println("\nCurrent sale history:");
            for (SaleEvent sale : property.getSaleHistory()) {
                System.out.println(sale);
            }
    
            System.out.print("\nWould you like to edit sale history? (yes/no): ");
            String editSales = keyboardIn.nextLine().toLowerCase();
    
            if (editSales.equals("yes")) {
                // Create a list to hold current sales
                List<SaleEvent> tempSales = new ArrayList<>(property.getSaleHistory());
            
                // Clear the property's sale history 
                property.getSaleHistory().clear();
            
                // Adds all existing sales
                for (SaleEvent sale : tempSales) {
                    System.out.print("Keep sale from " + sale.getYear() + " for $" + sale.getAmount() + "? (yes/no): ");
                    String keep = keyboardIn.nextLine().toLowerCase();
                    if (keep.equals("yes")) {
                        property.addSaleEvent(sale);
                    }
                }
            
                // Adds new sales
                boolean addMoreSales = true;
                while (addMoreSales) {
                    System.out.print("Enter year of sale (or 0 to stop adding): ");
                    int year = keyboardIn.nextInt();
                    if (year == 0) {
                        keyboardIn.nextLine();
                        break;
                    }
                    System.out.print("Enter sale price: ");
                    double salePrice = keyboardIn.nextDouble();
                    keyboardIn.nextLine();
                
                    property.addSaleEvent(new SaleEvent(year, salePrice));
                
                    System.out.print("Add another sale? (yes/no): ");
                    String response = keyboardIn.nextLine().toLowerCase();
                    addMoreSales = response.equals("yes");
                }
            }
    
            System.out.println("Property updated successfully.");
        } else {
            System.out.println("Invalid Property ID.");
        }
    }
    // Method used to find a property by ID
    private static Property findPropertyById(int id) {
        for (Property property : properties) {
            if (property.getId() == id) {
                return property;
            }
        }
        return null;
    }
    // Method used to display all property information
    private static void displayAllProperties() {
        if (properties.isEmpty()) {
            System.out.println("No properties found.");
            return;
        }
        for (Property property : properties) {
            System.out.printf("ID: %d, Price: $%.2f, Address: %s%n",
                    property.getId(), property.getPrice(), property.getAddress());
            if (!property.getSaleHistory().isEmpty()) {
                System.out.println("  Sale History:");
                for (SaleEvent sale : property.getSaleHistory()) {
                    System.out.println("    " + sale);
                }
            }
        }
    }

    // Assigns agent to a property
    public static void assignAgentToProperty() {
        System.out.println("-----------------\nCURRENT AGENTS:\n-----------------");
        displayAllAgents();
        System.out.println("-------------------\nCURRENT PROPERTIES:\n-------------------");
        displayAllProperties();
        
        System.out.print("Enter Property ID: ");
        int propertyId = keyboardIn.nextInt();
        keyboardIn.nextLine();
        
        System.out.print("Enter Agent ID: ");
        int agentId = keyboardIn.nextInt();
        keyboardIn.nextLine();
        
        Property property = findPropertyById(propertyId);
        if (property != null) {
            if (findAgentById(agentId) != null) {
                property.setAgentId(agentId);
                System.out.println("Agent assigned successfully.");
            } else {
                System.out.println("Invalid Agent ID.");
            }
        } else {
            System.out.println("Property not found.");
        }
    }
    // Assigns buyer/seller to a property
    public static void assignBuyerSellerToProperty() {
        System.out.println("---------------------------\nCURRENT BUYERS AND SELLERS:\n---------------------------");
        displayAllBuyerSellers();
        System.out.println("-------------------\nCURRENT PROPERTIES:\n-------------------");
        displayAllProperties();
        
        System.out.print("Enter Property ID: ");
        int propertyId = keyboardIn.nextInt();
        keyboardIn.nextLine();
        
        System.out.print("Enter Buyer/Seller ID: ");
        int buyerSellerId = keyboardIn.nextInt();
        keyboardIn.nextLine();
        
        Property property = findPropertyById(propertyId);
        if (property != null) {
            if (findBuyerSellerById(buyerSellerId) != null) {
                property.setBuyerSellerId(buyerSellerId);
                System.out.println("Buyer/Seller assigned successfully.");
            } else {
                System.out.println("Invalid Buyer/Seller ID.");
            }
        } else {
            System.out.println("Property not found.");
        }
    }

    // Method for saving data for agents, buyer/seller, properties, and assignments
    public static void saveData() {
        try {
            
            // Save agents
            PrintWriter agentOut = new PrintWriter(new FileWriter("agents.txt"));
            agentOut.printf("%-10s%-25s%-30s%-25s%n", "AGENT ID", "AGENT NAME", "AGENT EMAIL", "AGENT PHONE");
            for (Agent agent : agents) {
                agentOut.printf("%-10d%-25s%-30s%-25s%n", 
                        agent.getId(), agent.getName(), agent.getEmail(), agent.getPhone());
            }
            agentOut.close();

            // Save buyer/sellers
            PrintWriter buyerOut = new PrintWriter(new FileWriter("buyer_sellers.txt"));
            buyerOut.printf("%-34s%-30s%-30s%-30s%n", "BUYER/SELLER ID", "NAME", "EMAIL", "PHONE");
            for (BuyerSeller buyerSeller : buyerSellers) {
                buyerOut.printf("%-34d%-30s%-30s%-30s%n", 
                        buyerSeller.getId(), buyerSeller.getName(), buyerSeller.getEmail(), buyerSeller.getPhone());
            }
            buyerOut.close();

            // Save properties
            PrintWriter propertyOut = new PrintWriter(new FileWriter("properties.txt"));
            propertyOut.printf("%-34s%-30s%-30s%-30s%n", "PROPERTY ID", "PRICE", "ADDRESS", "SALE HISTORY");
            for (Property property : properties) {
                StringBuilder saleHistory = new StringBuilder();
                for (SaleEvent sale : property.getSaleHistory()) {
                    saleHistory.append(sale.getYear()).append(":").append(sale.getAmount()).append(";");
                }
                propertyOut.printf("%-34d%-30.1f%-30s%-30s%n", 
                        property.getId(), property.getPrice(), property.getAddress(), saleHistory.toString());
            }
            propertyOut.close();

            // Save assignments
            PrintWriter leadsOut = new PrintWriter(new FileWriter("salesLeads.txt"));
            leadsOut.printf("%-10s%-10s%-25s%-30s%-25s%-50s%n",
                    "LEAD ID", "AGENT ID", "SELLER NAME", "ADDRESS", "PHONE", "EMAIL");
            for (Agent agent : agents) {
                for (SalesLead lead : agent.getSalesLeads()) {
                    leadsOut.printf("%-10d%-10d%-25s%-30s%-25s%-50s%n",
                            lead.getId(), agent.getId(), lead.getSellerName(), lead.getLeadAddress(), lead.getPhone(), lead.getEmail());
                    saveLeadNote(lead.getId(), lead.getNote());
                }
            }
            leadsOut.close();
           
            System.out.println("Data saved successfully.");
        } catch (IOException ioex) {
            System.out.println("Error saving data: " + ioex.toString());
        }
    }
    // Saves sales leads note
    private static void saveLeadNote(int leadId, String note) {
        if (note == null || note.trim().isEmpty()) {
            return; 
        }
    
        try {
            PrintWriter noteOut = new PrintWriter(new FileWriter("lead_note_" + leadId + ".txt"));
            noteOut.println(note);
            noteOut.close();
        } catch (IOException ioex) {
            System.out.println("Error saving note for lead " + leadId + ": " + ioex.getMessage());
        }
    }


    public static void loadData() {
        try {
            
            // Load agents
            File agentFile = new File("agents.txt");
            if (agentFile.exists()) {
                Scanner agentIn = new Scanner(agentFile);
                agents.clear();
                // Skip header line
                if (agentIn.hasNextLine()) agentIn.nextLine();
                while (agentIn.hasNextLine()) {
                    String line = agentIn.nextLine().trim();
                    String[] parts = line.split("\\s{2,}"); 
                    if (parts.length >= 4) {
                        int id = Integer.parseInt(parts[0].trim());
                        String name = parts[1].trim();
                        String email = parts[2].trim();
                        String phone = parts[3].trim();
                        agents.add(new Agent(id, name, email, phone));
                    }
                }
                agentIn.close();
            }

            // Load buyer/sellers
            File buyerFile = new File("buyer_sellers.txt");
            if (buyerFile.exists()) {
                Scanner buyerIn = new Scanner(buyerFile);
                buyerSellers.clear();
                
                if (buyerIn.hasNextLine()) buyerIn.nextLine();
                while (buyerIn.hasNextLine()) {
                    String line = buyerIn.nextLine().trim();
                    String[] parts = line.split("\\s{2,}"); 
                    if (parts.length >= 4) {
                        int id = Integer.parseInt(parts[0].trim());
                        String name = parts[1].trim();
                        String email = parts[2].trim();
                        String phone = parts[3].trim();
                        buyerSellers.add(new BuyerSeller(id, name, email, phone));
                    }
                }
                buyerIn.close();
            }

            // Load properties
            File propertyFile = new File("properties.txt");
            if (propertyFile.exists()) {
                Scanner propertyIn = new Scanner(propertyFile);
                properties.clear();
                // Skip header line
                if (propertyIn.hasNextLine()) propertyIn.nextLine();
                while (propertyIn.hasNextLine()) {
                    String line = propertyIn.nextLine().trim();
                    String[] parts = line.split("\\s{2,}"); 
                    if (parts.length >= 3) {
                        int id = Integer.parseInt(parts[0].trim());
                        double price = Double.parseDouble(parts[1].trim());
                        String address = parts[2].trim();
                        Property property = new Property(id, address, price);
                    
                        // Load sale history if available
                        if (parts.length >= 4) {
                            String[] sales = parts[3].trim().split(";");
                            for (String sale : sales) {
                                if (!sale.isEmpty()) {
                                    String[] saleParts = sale.split(":");
                                    if (saleParts.length == 2) {
                                        int year = Integer.parseInt(saleParts[0]);
                                        double amount = Double.parseDouble(saleParts[1]);
                                        property.addSaleEvent(new SaleEvent(year, amount));
                                    }
                                }
                            }
                        }
                        properties.add(property);
                    }
                }
                propertyIn.close();
            }

            // Load assignments
            File assignmentFile = new File("property_assignments.txt");
            if (assignmentFile.exists()) {
                Scanner assignmentIn = new Scanner(assignmentFile);
                
                if (assignmentIn.hasNextLine()) assignmentIn.nextLine();
                while (assignmentIn.hasNextLine()) {
                    String line = assignmentIn.nextLine().trim();
                    String[] parts = line.split("\\s{2,}"); 
                    if (parts.length >= 3) {
                        int propertyId = Integer.parseInt(parts[0].trim());
                        int agentId = Integer.parseInt(parts[1].trim());
                        int buyerSellerId = Integer.parseInt(parts[2].trim());
                        
                        Property property = findPropertyById(propertyId);
                        if (property != null) {
                            property.setAgentId(agentId);
                            property.setBuyerSellerId(buyerSellerId);
                        }
                    }
                }
                assignmentIn.close();
            }
            
            // Load sales leads
            File leadsFile = new File("salesLeads.txt");
            if (leadsFile.exists()) {
                Scanner leadsIn = new Scanner(leadsFile);
                if (leadsIn.hasNextLine()) leadsIn.nextLine();
                while (leadsIn.hasNextLine()) {
                    String line = leadsIn.nextLine().trim();
                    String[] parts = line.split("\\s{2,}"); 
                    if (parts.length >= 6) {
                        int leadId = Integer.parseInt(parts[0].trim());
                        int agentId = Integer.parseInt(parts[1].trim());
                        String sellerName = parts[2].trim();
                        String address = parts[3].trim();
                        String phone = parts[4].trim();
                        String email = parts[5].trim();
                    
                        // Load note from separate file
                        String note = loadLeadNote(leadId);
                    
                        Agent agent = findAgentById(agentId);
                        if (agent != null) {
                            agent.addSalesLead(new SalesLead(leadId, sellerName, address, email, phone, note));
                        }
                    }
                }
                leadsIn.close();
            }

            System.out.println("Data loaded successfully.");
        } catch (IOException | NumberFormatException ioex) {
            System.out.println("Error loading data: " + ioex.getMessage());
        }
    }
    // Creates new notes for sales leads with their unique ID
    private static String loadLeadNote(int leadId) {
        try {
            File noteFile = new File("lead_note_" + leadId + ".txt");
            if (noteFile.exists()) {
                Scanner noteIn = new Scanner(noteFile);
                StringBuilder note = new StringBuilder();
                while (noteIn.hasNextLine()) {
                    note.append(noteIn.nextLine());
                    if (noteIn.hasNextLine()) {
                        note.append("\n");
                    }
                }
                noteIn.close();
                return note.toString();
            }
        } catch (IOException ioex) {
            System.out.println("Error loading note for lead " + leadId + ": " + ioex.getMessage());
        }
        return ""; 
    }

    // View the histogram
    public static void viewHistogram() {
        int[] bins = new int[5];
        for (Property property : properties) {
            double price = property.getPrice();
            if (price <= 200000) bins[0]++;
            else if (price <= 400000) bins[1]++;
            else if (price <= 600000) bins[2]++;
            else if (price <= 800000) bins[3]++;
            else bins[4]++;
        }
      
        System.out.println("\n$0 - $200k:      |" + repeatString("=", bins[0]) + " (" + bins[0] + ")");
        System.out.println("$200k - $400k:   |" + repeatString("=", bins[1]) + " (" + bins[1] + ")");
        System.out.println("$400k - $600k:   |" + repeatString("=", bins[2]) + " (" + bins[2] + ")");
        System.out.println("$600k - $800k:   |" + repeatString("=", bins[3]) + " (" + bins[3] + ")");
        System.out.println("$800k - $1m:     |" + repeatString("=", bins[4]) + " (" + bins[4] + ")\n");
    }

    public static String repeatString(String str, int count) {
        String result = "";
        for (int i=0; i<count; i++) {
            result += str;
        }
        return result;
    }

    // Prompts user to enter debtor name
    public static String getDebtorName(Scanner keyboardIn) {
        System.out.println("Please enter your name:");
        return keyboardIn.nextLine();
    }
    // Prompts user to enter amount borrowed replacing "$" and "%"
    public static double getAmountBorrowed(Scanner keyboardIn) {
        System.out.println("Please enter the amount you wish to borrow:");
        return replaceCurrencyInput(keyboardIn.nextLine());
    }
    // Prompts user to enter interest rate replacing "%"
    public static double getInterestRate(Scanner keyboardIn) {
        System.out.println("Please enter your desired interest rate:");
        return replacePercentageInput(keyboardIn.nextLine());
    }
    // Prompts user to enter down payment replacing "$" and ","
    public static double getDownPayment(Scanner keyboardIn) {
        System.out.println("Please enter your expected down payment:");
        return replaceCurrencyInput(keyboardIn.nextLine());
    }
    // Calculates loan amount
    public static double calculateLoanAmount(double amtBorrowed, double downPayment) {
        return amtBorrowed - downPayment;
    }
    // Calculates monthly interest
    public static double calculateMonthlyInterestRate(double interestRate) {
        return (interestRate / 100) / 12;
    }
    // Calculates total payments
    public static int calculateTotalPayments(int loanTermYears) {
        return loanTermYears * 12;
    }
    // Calculates monthly payments
    public static double calculateMonthlyPayment(double loanAmount, double monthlyInterestRate, int totalPayments) {
        return (loanAmount * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, totalPayments))
                / (Math.pow(1 + monthlyInterestRate, totalPayments) - 1);
    }
    // Display amortization schedule of 15-/30-year loan
    public static String DisplayAmortizationSchedule(String loanTerm, String debtorName, double loanAmount,
            double monthlyPayment, double monthlyInterestRate, int totalPayments) {
        StringBuffer schedule = new StringBuffer(); 
    
        schedule.append("\nName: ").append(debtorName).append("\n");
        schedule.append(String.format("\n%s monthly Payment: $%.2f\n", loanTerm, monthlyPayment));
        schedule.append("\n").append(loanTerm).append(" Amortization Schedule:\n");
        schedule.append("Month # | Payment | Principal | Interest | Balance Remaining\n");

        double remainingBalance = loanAmount;
        double totalInterestPaid = 0.0;
        double totalPrincipalPaid = 0.0;

        for (int i = 0; i < totalPayments; i++) {
            double interest = remainingBalance * monthlyInterestRate;
            double principal = monthlyPayment - interest;
            remainingBalance -= principal;
            totalInterestPaid += interest;
            totalPrincipalPaid += principal;

            if (remainingBalance < 0) {
                remainingBalance = 0.0;
            }

            schedule.append(String.format("%7d | $%.2f | $%7.2f | $%.2f | $%.2f\n",
                    i + 1, monthlyPayment, principal, interest, remainingBalance));
        }

        schedule.append(String.format("\nTotal Interest Paid: $%.2f", totalInterestPaid));
        schedule.append(String.format("\nTotal Principal Paid: $%.2f\n", totalPrincipalPaid));
    
        return schedule.toString();
    }

    // Prompts user to run program again in certain methods
    public static boolean askToRunAgain(Scanner keyboardIn) {
        System.out.println("\n\nWould you like to run the program again? (yes/no): ");
        String response = keyboardIn.nextLine().toLowerCase();
        return response.equals("yes");
    }
    // Method used to replace "$" and "," in the amount borrowed and down payments of the amortization/add properties
    public static double replaceCurrencyInput(String input) {
        return Double.parseDouble(input.replaceAll("[,$]", ""));
    }
    // Method used to replace "%" symbol in the interest rate prompt of amortization
    public static double replacePercentageInput(String input) {
        return Double.parseDouble(input.replace("%", ""));
    }

    // amortization method used to get all data requirements and calculate 15-/30-year loan information
    public static void amortizationHomeLoan() {
        boolean runAgain = true;
    
        while (runAgain) {
            String debtorName = getDebtorName(keyboardIn);
            double amtBorrowed = getAmountBorrowed(keyboardIn);
            double interestRate = getInterestRate(keyboardIn);
            double downPayment = getDownPayment(keyboardIn);

            double loanAmount = calculateLoanAmount(amtBorrowed, downPayment);
            double monthlyInterestRate = calculateMonthlyInterestRate(interestRate);

            int loanTerm15Years = 15;
            int totalPayments15Years = calculateTotalPayments(loanTerm15Years);
            double monthlyPayment15Years = calculateMonthlyPayment(loanAmount, monthlyInterestRate, totalPayments15Years);
            String schedule15Years = DisplayAmortizationSchedule("15 Year", debtorName, loanAmount, 
                    monthlyPayment15Years, monthlyInterestRate, totalPayments15Years);
            System.out.println(schedule15Years);

            int loanTerm30Years = 30;
            int totalPayments30Years = calculateTotalPayments(loanTerm30Years);
            double monthlyPayment30Years = calculateMonthlyPayment(loanAmount, monthlyInterestRate, totalPayments30Years);
            String schedule30Years = DisplayAmortizationSchedule("30 Year", debtorName, loanAmount, 
                    monthlyPayment30Years, monthlyInterestRate, totalPayments30Years);
            System.out.println(schedule30Years);

            
            saveAmortizationData(debtorName, schedule15Years, schedule30Years);
        
            runAgain = askToRunAgain(keyboardIn);
        }
    }
    
    // Saves amortization information for users to text file
    private static void saveAmortizationData(String debtorName, String schedule15, String schedule30) {
        try {
            String fileName = "amortization_" + debtorName.replaceAll("\\s+", "_").toLowerCase();
        
            
            File directory = new File(".");
            File[] existingFiles = directory.listFiles((dir, name) -> 
                    name.toLowerCase().startsWith(fileName) && name.toLowerCase().endsWith(".txt"));
        
            int nextFileNumber = 1;
            if (existingFiles != null && existingFiles.length > 0) {
                nextFileNumber = existingFiles.length + 1;
            }
        
            
            String filename = fileName + "_" + nextFileNumber + ".txt";
        
            PrintWriter amortizationOut = new PrintWriter(new FileWriter(filename));
        
            amortizationOut.println("AMORTIZATION SCHEDULES FOR: " + debtorName);
            amortizationOut.println("Record #" + nextFileNumber);
            amortizationOut.println("Generated on: " + new Date());
            amortizationOut.println("\n==========================================");
            amortizationOut.println("15 YEAR AMORTIZATION SCHEDULE");
            amortizationOut.println("==========================================");
            amortizationOut.println(schedule15);
        
            amortizationOut.println("\n==========================================");
            amortizationOut.println("30 YEAR AMORTIZATION SCHEDULE");
            amortizationOut.println("==========================================");
            amortizationOut.println(schedule30);
        
            amortizationOut.close();
            System.out.println("Amortization schedules saved to: " + filename);
        } catch (IOException ioex) {
            System.out.println("Error saving amortization data: " + ioex.getMessage());
        }
    }

    // Loads amortization information that is saved to users
    private static void loadAmortization() {
        System.out.print("Enter your name to load your amortization records: ");
        String nameToLoad = keyboardIn.nextLine().trim();
    
        
        String fileName = "amortization_" + nameToLoad.replaceAll("\\s+", "_").toLowerCase();
        File directory = new File(".");
    
        
        File[] allFiles = directory.listFiles((dir, name) -> 
            name.toLowerCase().startsWith(fileName) && name.toLowerCase().endsWith(".txt"));
    
        if (allFiles == null || allFiles.length == 0) {
            System.out.println("No amortization records found for " + nameToLoad);
            return;
        }
        
        Arrays.sort(allFiles, (f1, f2) -> {
            try {
                int num1 = Integer.parseInt(f1.getName().replace(fileName + "_", "").replace(".txt", ""));
                int num2 = Integer.parseInt(f2.getName().replace(fileName + "_", "").replace(".txt", ""));
                return Integer.compare(num1, num2);
            } catch (NumberFormatException ioex) {
                return f1.getName().compareTo(f2.getName());
            }
        });
    
        System.out.println("\nAmortization records for " + nameToLoad + ":");
        System.out.println("----------------------------------------");
        for (int i = 0; i < allFiles.length; i++) {
            
            String numStr = allFiles[i].getName().replace(fileName + "_", "").replace(".txt", "");
        
            System.out.println((i+1) + ". Record #" + numStr);
  
        }
    
        System.out.print("\nEnter the number of the record to view (0 to cancel): ");
        int choice = keyboardIn.nextInt();
        keyboardIn.nextLine();
    
        if (choice > 0 && choice <= allFiles.length) {
            try {
                Scanner amortizationIn = new Scanner(allFiles[choice-1]);
                System.out.println("\n==========================================");
                System.out.println("VIEWING RECORD #" + 
                    allFiles[choice-1].getName().replace(fileName + "_", "").replace(".txt", ""));
                System.out.println("==========================================");
                while (amortizationIn.hasNextLine()) {
                    System.out.println(amortizationIn.nextLine());
                }
                amortizationIn.close();
            } catch (IOException ioex) {
                System.out.println("Error reading file: " + ioex.getMessage());
            }
        }
    
        System.out.print("\nWould you like to create a new amortization table? (yes/no): ");
        String response = keyboardIn.nextLine().toLowerCase();
        if (response.equals("yes")) {
            amortizationHomeLoan();
        }
    }
    // Method called from menu to select agents
    public static void selectAgent() {
        System.out.println("\n--- Select Agent ---");
        displayAllAgents();
        if (agents.isEmpty()) {
            System.out.println("No agents available.");
            return;
        }
        
        System.out.print("\nEnter Agent ID to view: ");
        int agentId = keyboardIn.nextInt();
        keyboardIn.nextLine();

        Agent agent = findAgentById(agentId);
        if (agent == null) {
            System.out.println("Invalid Agent ID.");
            return;
        }

        System.out.println("\n--- Sales Leads for Agent " + agent.getName() + " ---");
        if (agent.getSalesLeads().isEmpty()) {
            System.out.println("This agent has no sales leads.");
        } else {
            displayAgentSalesLeads(agent);
        }

        System.out.print("\nEnter Sales Lead ID to view details (or 0 to view assigned properties): ");
        int leadId = keyboardIn.nextInt();
        keyboardIn.nextLine();

        if (leadId == 0) {
            
            System.out.println("\n--- Properties Assigned to Agent " + agent.getName() + " ---");
            boolean hasProperties = false;
        
            for (Property property : properties) {
                if (property.getAgentId() == agentId) {
                    System.out.printf("ID: %d, Price: $%.2f, Address: %s%n",
                            property.getId(), property.getPrice(), property.getAddress());
                    if (!property.getSaleHistory().isEmpty()) {
                        System.out.println("  Sale History:");
                        for (SaleEvent sale : property.getSaleHistory()) {
                            System.out.println("    " + sale);
                        }
                    }
                    hasProperties = true;
                }
            }
        
            if (!hasProperties) {
                System.out.println("This agent has no assigned properties.");
            }
        } else {
            
            SalesLead lead = findSalesLeadById(agent, leadId);
            if (lead == null) {
                System.out.println("Invalid Sales Lead ID.");
                return;
            }
            
            displaySalesLeadDetails(lead);

            System.out.print("\nWould you like to edit this note? (yes/no): ");
            String response = keyboardIn.nextLine().toLowerCase();

            if (response.equals("yes")) {
                editSalesLeadNote(lead);
                System.out.println("Note updated successfully.");
            }
        }

        
        System.out.print("\nPress Enter to return to menu: ");
        keyboardIn.nextLine();
    }
    // Method to display sales leads for particular agents
    private static void displayAgentSalesLeads(Agent agent) {
        System.out.println("\nSales Leads for Agent " + agent.getName() + ":");
        System.out.printf("%-10s%-25s%-30s%-25s%-50s%n", 
                "LEAD ID", "SELLER NAME", "ADDRESS", "PHONE", "EMAIL");
    
        for (SalesLead lead : agent.getSalesLeads()) {
            System.out.printf("%-10d%-25s%-30s%-25s%-50s%n",
                    lead.getId(), lead.getSellerName(), 
                    lead.getLeadAddress(), lead.getPhone(), lead.getEmail());
        }
    }
    // Method to get sales lead ID
    private static SalesLead findSalesLeadById(Agent agent, int leadId) {
        for (SalesLead lead : agent.getSalesLeads()) {
            if (lead.getId() == leadId) {
                return lead;
            }
        }
        return null;
    }
    // Method to display details of sales leads
    private static void displaySalesLeadDetails(SalesLead lead) {
        System.out.println("\n--- Sales Lead Details ---");
        System.out.println("ID: " + lead.getId());
        System.out.println("Seller Name: " + lead.getSellerName());
        System.out.println("Address: " + lead.getLeadAddress());
        System.out.println("Phone: " + lead.getPhone());
        System.out.println("Email: " + lead.getEmail());
        System.out.println("\nNote:");
        System.out.println(lead.getNote() != null ? lead.getNote() : "No note available");
    }
    
    // Allows user to edit note of sales lead for an agent
    private static void editSalesLeadNote(SalesLead lead) {
        System.out.println("\nCurrent note:");
        System.out.println(lead.getNote() != null ? lead.getNote() : "No note available");
        System.out.println("\nEnter new note (press Enter to keep current note):");
        String newNote = keyboardIn.nextLine();
    
        if (!newNote.trim().isEmpty()) {
            
            lead.setNote(newNote);
        
            
            saveLeadNote(lead.getId(), newNote);
        }
    }
    
    // Method called from menu to display all current properties in system
    public static void selectProperty() {
        System.out.println("\n--- Current Properties ---");
    
        if (properties.isEmpty()) {
            System.out.println("No properties found in the system.");
        } else {
            
            for (Property property : properties) {
                System.out.println("\nProperty ID: " + property.getId());
                System.out.println("Address: " + property.getAddress());
                System.out.printf("Price: $%.2f%n", property.getPrice());
            
                if (property.getAgentId() != 0) {
                    Agent agent = findAgentById(property.getAgentId());
                    if (agent != null) {
                        System.out.println("Assigned Agent: " + agent.getName() + " (ID: " + agent.getId() + ")");
                    } else {
                        System.out.println("Assigned Agent: [Agent not found]");
                    }
                } else {
                    System.out.println("Assigned Agent: None");
                }
            
                if (property.getBuyerSellerId() != 0) {
                    BuyerSeller buyerSeller = findBuyerSellerById(property.getBuyerSellerId());
                    if (buyerSeller != null) {
                        System.out.println("Assigned Buyer/Seller: " + buyerSeller.getName() + " (ID: " + buyerSeller.getId() + ")");
                    } else {
                        System.out.println("Assigned Buyer/Seller: [Buyer/Seller not found]");
                    }
                } else {
                    System.out.println("Assigned Buyer/Seller: None");
                }
            
                if (!property.getSaleHistory().isEmpty()) {
                    System.out.println("Sale History:");
                    for (SaleEvent sale : property.getSaleHistory()) {
                        System.out.println("  " + sale);
                    }
                } else {
                    System.out.println("Sale History: None");
                }
            }
        }
        System.out.print("\nPress Enter to return to the main menu: ");
        keyboardIn.nextLine();
    }
}

    

    

     

    

