
package com.mycompany.cis331project3;

public class LoanInfo {
    // Data Types
    private double loanAmount;
    private int termYears;
    private double annualRate;
    // Constructors
    public LoanInfo(double loanAmount, int termYears, double annualRate) {
        this.loanAmount = loanAmount;
        this.termYears = termYears;
        this.annualRate = annualRate;
    }
    // Member Methods
    // Getters  
    public double getLoanAmount() { return loanAmount; }
    public int getTermYears() { return termYears; }
    public double getAnnualRate() { return annualRate; }
} 
    

