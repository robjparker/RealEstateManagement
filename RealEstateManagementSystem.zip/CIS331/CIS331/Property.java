
package com.mycompany.cis331project3;

import java.util.*;

public class Property {
    // Data Types
    private int id;
    private String address;
    private double price;
    private int agentId;
    private int buyerSellerId;
    private List<SaleEvent> saleHistory = new ArrayList<>();
    // Constructors
    public Property(int id, String address, double price) {
        this.id = id;
        this.address = address;
        this.price = price;
        this.agentId = 0; 
        this.buyerSellerId = 0;
        
    }
    // Member Methods
    // Getters    
    public int getId() { return id; }
    public String getAddress() { return address; }
    public double getPrice() { return price; }
    public int getAgentId() { return agentId; }
    public int getBuyerSellerId() { return buyerSellerId; }
    public List<SaleEvent> getSaleHistory() { return saleHistory; }
    // Setters
    public void setAddress(String address) { this.address = address; }
    public void setPrice(double price) { this.price = price; }
    public void setAgentId(int agentId) { this.agentId = agentId; }
    public void setBuyerSellerId(int buyerSellerId) { this.buyerSellerId = buyerSellerId; }
    // Assigns sales event to a property
    public void addSaleEvent(SaleEvent event) { this.saleHistory.add(event); }
}
    

