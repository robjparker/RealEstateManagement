
package com.mycompany.cis331project3;

public class SaleEvent {
    // Data Types
    private int year;
    private double amount;
    // Constructors
    public SaleEvent(int year, double amount) {
        this.year = year;
        this.amount = amount;
    }
    // Member Methods
    // Getters 
    public int getYear() { return year; }
    public double getAmount() { return amount; }
    // Provides a string representation of the sale event
    @Override
    public String toString() {
        return "Year: " + year + ", Amount: $" + amount;
    }
}
    

