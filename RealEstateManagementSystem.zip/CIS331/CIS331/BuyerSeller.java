
package com.mycompany.cis331project3;

import java.util.*;

public class BuyerSeller {
    // Data Types
    private int id;
    private String name;
    private String email;
    private String phone;
    private List<LoanInfo> loanHistory = new ArrayList<>();
    
    // Constructors
    public BuyerSeller(int id, String name, String email, String phone) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
    }

    // Member Methods
    // Getters      
    public int getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public List<LoanInfo> getLoanHistory() { return loanHistory; }
    // Setters    
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setPhone(String phone) { this.phone = phone; }
    public void addLoanInfo(LoanInfo loanInfo) { this.loanHistory.add(loanInfo); }
    
}

