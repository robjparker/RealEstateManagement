
package com.mycompany.cis331project3;

import java.util.*;

public class Agent {
    // Data Types
    private int id;
    private String name;
    private String email;
    private String phone;
    private List<SalesLead> salesLeads = new ArrayList<>();
    private List<String> notes = new ArrayList<>();
       
    // Constructors
    public Agent(int id, String name, String email, String phone) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
    }
    // Member Methods
    // Getters    
    public int getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public List<SalesLead> getSalesLeads() { return salesLeads; }
    public List<String> getNotes() { return notes; }
    public void addNote(String note) { this.notes.add(note); }
    // Setters 
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setPhone(String phone) { this.phone = phone; }
    // Assigns a new sales lead to this agent
    public void addSalesLead(SalesLead lead) { this.salesLeads.add(lead); }
}
    

