package com.mycompany.realtyproject;

import java.util.*;
import java.io.Serializable;

/**
 * A class representing a real estate agent.
 * 
 * @author Simon Fossett, Rob Parker, and Jeffrey Sterns
 * @version 1.0
 */
public class Agent implements Serializable {
    // Data Types
    private int id;
    private String name;
    private String email;
    private String phone;
    private List<SalesLead> salesLeads = new ArrayList<>();
    private List<String> notes = new ArrayList<>();
       
    /**
     * Construct the agent object.
     * @param id the agent's ID.
     * @param name the name of the agent.
     * @param email the agent's email.
     * @param phone the phone # of the agent.
     */
    public Agent(int id, String name, String email, String phone) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
    }
    
 
    /**
     * Get the realtor's ID.
     * @return the realtor's ID.
     */
    public int getId() { return id; }
    
    
    /**
     * Get the realtor's name.
     * @return the realtor's name.
     */
    public String getName() { return name; }
    
    
    /**
     * Get the realtor's email.
     * @return the realtor's email.
     */
    public String getEmail() { return email; }
    
    
    /**
     * Get the realtor's phone.
     * @return the realtor's phone.
     */
    public String getPhone() { return phone; }
    
    
    /**
     * Get the realtor's sales leads.
     * @return the realtor's sales lead.
     */
    public List<SalesLead> getSalesLeads() { return salesLeads; }
    
    
    /**
     * Get the realtor's notes.
     * @return the realtor's notes.
     */
    public List<String> getNotes() { return notes; }
    
    
    /**
     * Add a note to the realtor.
     * @param note the note to add.
     */
    public void addNote(String note) { this.notes.add(note); }
    
    
    /**
     * Set the realtor's name.
     * @param name the realtor's new name.
     */
    public void setName(String name) { this.name = name; }
    
    
    /**
     * Set the realtor's email.
     * @param email the realtor's new email.
     */
    public void setEmail(String email) { this.email = email; }
    
    
    /**
     * Set the realtor's phone #.
     * @param phone the realtor's new phone #.
     */
    public void setPhone(String phone) { this.phone = phone; }

    
    /**
     * Add a new sales lead to the realtor.
     * @param lead the new sales lead.
     */
    public void addSalesLead(SalesLead lead) { this.salesLeads.add(lead); }
}
    

