package com.mycompany.realtyproject;

import java.io.*;
import java.text.FieldPosition;
import java.util.ArrayList;
/**
 * A class with static methods for loading important elements from file, such as buyers, sellers, properties, and agents.
 * 
 * @author John Ryder and Jelal Kaufman
 * @version 1.0
 */
public class LoadElements {
    
    /**
     * Load the buyers/sellers from file buyers_sellers.rp.
     * @return an ArrayList<BuyerSeller> if loaded successfully, or null if not.
     */
    public static ArrayList<BuyerSeller> loadBuyerSellers()
    {
        try
        {
            FileInputStream inStream = new FileInputStream("buyers_sellers.rp");
            ObjectInputStream objIn = new ObjectInputStream(inStream);
            ArrayList<BuyerSeller> loadedData = (ArrayList<BuyerSeller>) objIn.readObject();
            return loadedData;
        }
        catch (IOException e) {
            return null;
        }
        catch (ClassNotFoundException e) {
            return null;
        }
    }
    
    
    /**
     * Load the properties from file properties.rp.
     * @return an ArrayList<Property> if loaded successfully, or null if not.
     */
    public static ArrayList<Property> loadProperties()
    {
        try
        {
            FileInputStream inStream = new FileInputStream("properties.rp");
            ObjectInputStream objIn = new ObjectInputStream(inStream);
            ArrayList<Property> loadedData = (ArrayList<Property>) objIn.readObject();
            return loadedData;
        }
        catch (IOException e) {
            return null;
        }
        catch (ClassNotFoundException e) {
            return null;
        }
    }
    
    
    /**
     * Load the agents from the file agents.rp.
     * @return an ArrayList<Agent> if loaded successfully, or null if not.
     */
    public static ArrayList<Agent> loadAgents()
    {
        try
        {
            FileInputStream inStream = new FileInputStream("agents.rp");
            ObjectInputStream objIn = new ObjectInputStream(inStream);
            ArrayList<Agent> loadedData = (ArrayList<Agent>) objIn.readObject();
            return loadedData;
        }
        catch (IOException e) {
            return null;
        }
        catch (ClassNotFoundException e) {
            return null;
        } 
    }  
}
