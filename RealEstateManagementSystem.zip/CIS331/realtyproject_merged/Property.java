
package com.mycompany.realtyproject;

import java.util.*;
import java.io.Serializable;

/**
 * A class representing properties.
 * 
 * @author Simon Fossett, Rob Parker, and Jeffrey Sterns
 * @version 1.0
 */
public class Property implements Serializable {
    
    private int id;
    private String address;
    private double price;
    private int agentId;
    private int buyerSellerId;
    private List<SaleEvent> saleHistory = new ArrayList<>();

    
    /**
     * Construct the property object.
     * @param id the ID of the property.
     * @param address the address of the property.
     * @param price the price of the property.
     */
    public Property(int id, String address, double price) {
        this.id = id;
        this.address = address;
        this.price = price;
        this.agentId = 0; 
        this.buyerSellerId = 0;
        
    }

    /**
     * Get the property's ID.
     * @return the property's ID.
     */
    public int getId() { return id; }
    
    
    /**
     * Get the property's address.
     * @return the property's address.
     */
    public String getAddress() { return address; }
    
    
    /**
     * Get the price of the property.
     * @return the price of the property.
     */
    public double getPrice() { return price; }
    
    
    /**
     * Get the ID of the real estate agent associated with this property.
     * @return the ID of the real estate agent associated with this property.
     */
    public int getAgentId() { return agentId; }
    
    /**
     * Get the buyer/seller ID associated with this property.
     * @return the buyer/seller ID associated with this property.
     */
    public int getBuyerSellerId() { return buyerSellerId; }
    
    
    /**
     * Get this property's sale history.
     * @return this property's sale history.
     */
    public List<SaleEvent> getSaleHistory() { return saleHistory; }

    
    /**
     * Set this property's address.
     * @param address this property's new address.
     */
    public void setAddress(String address) { this.address = address; }
    
    
    /**
     * Set this property's price.
     * @param price this property's new price
     */
    public void setPrice(double price) { this.price = price; }
    
    
    /**
     * Set the agent's ID associated with this property.
     * @param agentId the new agent's ID.
     */
    public void setAgentId(int agentId) { this.agentId = agentId; }
    
    
    /**
     * Set the buyer/seller ID associated with this property.
     * @param buyerSellerId the new buyer/seller's ID.
     */
    public void setBuyerSellerId(int buyerSellerId) { this.buyerSellerId = buyerSellerId; }
    
    
    /**
     * Add a sale event to this property.
     * @param event the new sale event to be added.
     */
    public void addSaleEvent(SaleEvent event) { this.saleHistory.add(event); }
}
    

