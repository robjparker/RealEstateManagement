package com.mycompany.realtyproject;

import java.util.*;
import java.io.Serializable;

/**
 * A class representing a realtor's sales leads.
 * 
 * @author Simon Fossett, Rob Parker, and Jeffrey Sterns
 * @version 1.0
 */
public class SalesLead implements Serializable {

    private int id;
    private String sellerName;
    private String leadAddress;
    private String email;
    private String phone;
    private String note;
    
    
    /**
     * Construct the sales lead event.
     * @param id the ID of the sales event.
     * @param sellerName the name of the seller.
     * @param leadAddress the address of the lead.
     * @param email the email of the seller.
     * @param phone the phone of the seller.
     * @param note the note associated with the lead.
     */
    public SalesLead(int id, String sellerName, String leadAddress, String email, String phone, String note) {
        this.id = id;
        this.sellerName = sellerName;
        this.leadAddress = leadAddress;
        this.email = email;
        this.phone = phone;
        this.note = note;
    }
    
    /**
     * Construct the sales lead event without seller email, seller phone, or a note.
     * @param id the ID of the lead.
     * @param sellerName the name of the seller.
     * @param leadAddress the address of the lead.
     */
    public SalesLead (int id, String sellerName, String leadAddress) {
        this.id = id;
        this.sellerName = sellerName;
        this.leadAddress = leadAddress;
    }
    
    
    /**
     * Get the lead's ID.
     * @return the lead's ID
     */
    public int getId() { return id; }
    
    
    /**
     * Get the seller's name.
     * @return the seller's name.
     */
    public String getSellerName() { return sellerName; }
    
    
    /**
     * Get the address of the lead.
     * @return the address of the lead.
     */
    public String getLeadAddress() { return leadAddress; }
    
    
    /**
     * Get the email of the seller.
     * @return the seller's email.
     */
    public String getEmail() { return email; }
    
    
    /**
     * Get the seller's phone
     * @return the seller's phone.
     */
    public String getPhone() { return phone; }
    
    
    /**
     * Get the note associated with the lead.
     * @return the note associated with the lead.
     */
    public String getNote() { return note; }

    
    /**
     * Set the note associated with this lead.
     * @param note the new note.
     */
    public void setNote(String note) { this.note = note; }
    
    
    // Provides a string representation of the sales leads information
    @Override
    public String toString() {
        return "Lead Seller: " + sellerName + "Lead Address: " + leadAddress + "Email: " + email + ", Phone: " + phone + 
                (note != null ? ", Note: " + note : "");
    }
}
    

