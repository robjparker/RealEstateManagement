package com.mycompany.realtyproject;

import java.io.*;
import java.util.ArrayList;

/**
 * Save important elements such as buyers, sellers, properties, and agents via serialization.
 * 
 * @author John Ryder and Jelal Kaufman
 * @version 1.0
 */
public class SaveElements {
    
    /**
     * Save the buyers/sellers to buyers_sellers.rp.
     * @param buyersSellers list of buyers/sellers to save.
     * @return true if successful, false if not.
     */
    public static boolean saveBuyerSellers(ArrayList<BuyerSeller> buyersSellers)
    {
        FileOutputStream fileStream = null;
        ObjectOutputStream objOut = null;
        try
        {
            fileStream = new FileOutputStream("buyers_sellers.rp");
            objOut = new ObjectOutputStream(fileStream);
            objOut.writeObject(buyersSellers);
            objOut.close();
            return true;
        } 
        catch (IOException e)
        {
            return false;
        }
    }
    
    
    /**
     * Save the properties to properties.rp.
     * @param properties the list of properties to save.
     * @return true if successful, false if not.
     */
    public static boolean saveProperties(ArrayList<Property> properties)
    {
        FileOutputStream fileStream = null;
        ObjectOutputStream objOut = null;
        try
        {
            fileStream = new FileOutputStream("properties.rp");
            objOut = new ObjectOutputStream(fileStream);
            objOut.writeObject(properties);
            objOut.close();
            return true;
        }
        catch (IOException e)
        {
            return false;
        }
    }
    
    
    /**
     * Save the agents to agents.rp.
     * @param agents the list of agents to save.
     * @return true if successful, false if not.
     */
    public static boolean saveAgents(ArrayList<Agent> agents)
    {
        FileOutputStream fileStream = null;
        ObjectOutputStream objOut = null;
        try
        {
            fileStream = new FileOutputStream("agents.rp");
            objOut = new ObjectOutputStream(fileStream);
            objOut.writeObject(agents);
            objOut.close();
            return true;
        }
        catch (IOException e)
        {
            return false;
        }
    }
}
