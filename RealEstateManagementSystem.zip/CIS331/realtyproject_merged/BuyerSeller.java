package com.mycompany.realtyproject;

import java.io.Serializable;
import java.util.*;

/**
 * A class representing a buyer or seller.
 * 
 * @author Simon Fossett, Rob Parker, and Jeffrey Sterns
 * @version 1.0
 */
public class BuyerSeller implements Serializable{
    // Data Types
    private int id;
    private String name;
    private String email;
    private String phone;
    private List<LoanInfo> loanHistory = new ArrayList<>();
    
    
    /**
     * Construct the buyer/seller.
     * @param id the buyer/seller's ID.
     * @param name the name of the buyer/seller.
     * @param email the email of the buyer/seller.
     * @param phone the phone # of the buyer/seller.
     */
    public BuyerSeller(int id, String name, String email, String phone) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
    }


    /**
     * Get the buyer/seller's ID
     * @return the buyer/seller's ID.
     */
    public int getId() { return id; }
    
    
    /**
     * Get the buyer/seller's name.
     * @return the buyer/seller's name.
     */
    public String getName() { return name; }
    
    
    /**
     * Get the buyer/seller's email.
     * @return the buyer/seller's email.
     */
    public String getEmail() { return email; }
    
    
    /**
     * Get the buyer/seller's phone #.
     * @return the buyer/seller's phone #.
     */
    public String getPhone() { return phone; }
    
    
    /**
     * Get the buyer/seller's phone #.
     * @return the buyer/seller's phone #.
     */
    public List<LoanInfo> getLoanHistory() { return loanHistory; }
    
    
    /**
     * Set the buyer/seller's name.
     * @param name the buyer/seller's new name.
     */
    public void setName(String name) { this.name = name; }
    
    
    /**
     * Set the buyer/seller's email.
     * @param email the buyer/seller's new email.
     */
    public void setEmail(String email) { this.email = email; }
    
    
    /**
     * Set the phone # of the buyer/seller.
     * @param phone the buyer/seller's new phone #.
     */
    public void setPhone(String phone) { this.phone = phone; }
    
    
    /**
     * Add loan info to this buyer/seller's history.
     * @param loanInfo the loan info to add.
     */
    public void addLoanInfo(LoanInfo loanInfo) { this.loanHistory.add(loanInfo); }
    
}

