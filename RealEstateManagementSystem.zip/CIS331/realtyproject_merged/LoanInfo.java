package com.mycompany.realtyproject;

/**
 * A class representing information about loans.
 * 
 * @author Simon Fossett, Rob Parker, and Jeffrey Sterns
 * @version 1.0
 */
public class LoanInfo {
    
    private double loanAmount;
    private int termYears;
    private double annualRate;

    
    /**
     * Construct the loan info object.
     * @param loanAmount the amount loaned.
     * @param termYears how long the loan is for.
     * @param annualRate the annual rate of interest.
     */
    public LoanInfo(double loanAmount, int termYears, double annualRate) {
        this.loanAmount = loanAmount;
        this.termYears = termYears;
        this.annualRate = annualRate;
    }
    
    
    /**
     * Get the loan amount.
     * @return the loan amount.
     */
    public double getLoanAmount() { return loanAmount; }
    
    
    /**
     * Get the length of the loan.
     * @return the length of the loan.
     */
    public int getTermYears() { return termYears; }
    
    
    /**
     * Get the annual rate of interest.
     * @return the annual rate of interest.
     */
    public double getAnnualRate() { return annualRate; }
} 
    

