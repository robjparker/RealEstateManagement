package com.mycompany.realtyproject;

import java.io.Serializable;

/**
 * A class representing a sale event regarding a property.
 * 
 * @author Simon Fossett, Rob Parker, and Jeffrey Sterns
 * @version 1.0
 */
public class SaleEvent implements Serializable {

    private int year;
    private double amount;
    
    /**
     * Construct the sale event.
     * @param year the year the sale occurred.
     * @param amount the amount the property was sold for.
     */
    public SaleEvent(int year, double amount) {
        this.year = year;
        this.amount = amount;
    }
    
    
    /**
     * Get the year of sale.
     * @return the year of sale.
     */
    public int getYear() { return year; }
    
    
    /**
     * Get the amount of sale.
     * @return the amount of sale.
     */
    public double getAmount() { return amount; }
    
    
    // Provides a string representation of the sale event
    @Override
    public String toString() {
        return "Year: " + year + ", Amount: $" + amount;
    }
}
    

